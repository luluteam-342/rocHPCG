
void ComputeOptimalShapeXYZ(int xyz, int & x, int & y, int & z);
